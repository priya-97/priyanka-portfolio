
#------------------------------------------------Movies Project--------------------------------------------------------------------#
use movie_project;
select * from movies;

#1.Retrieve the names of all the Bollywood movies which are of drama genre in the dataset.
select movie_name from movies where genre='drama';

#2.Retrieve the names of all the Bollywood movies of Amir Khan in the dataset.
select movie_name from movies where lead_star='Aamir khan';

#3.Retrieve the names of all the Bollywood movies which are directed by RamGopal Verma in the dataset.
select movie_name from movies where director='Ram Gopal Verma'; 	

#4.Retrieve the names of all the Bollywood movies which have been released over more than 1000 number of screens in the dataset.
select movie_name from movies where Number_of_Screens>1000;

#5.Retrieve the names of all the Bollywood movies which have generated Revenue(INR) more than 700000000 in the dataset.
select movie_name from movies where Revenue >700000000;

#6.Retrieve the names of all the Bollywood movies which have budget less than 1cr in the dataset.
select movie_name from movies where Budget<10000000;

#7. Retrieve the names of all the Bollywood movies which are flop in the dataset.(flop=revenue – budget)
select movie_name as flop from movies where(revenue-budget)<0;

#8.Retrieve the names and profit of all the Bollywood movies in the dataset.(profit=revenue – budget)
select movie_name as profit from movies where(revenue-budget)>0;

#9.Retrieve the names and loss of all the Bollywood movies in the dataset.(loss=revenue – budget)
select movie_name as loss from movies where(revenue-budget)<0;

#10.Retrieve the names of all the Bollywood movies which have been released on holidays in the dataset.
select movie_name from movies where Release_Period='Holiday';

#11.Retrieve the names of all the Bollywood movies which have lead star as Akshay Kumar and directed by Priyadarshan in the dataset.
select movie_name from movies where Lead_Star='Akshay Kumar' AND Director='Priyadarshan';

#12. Retrieve the names of all the Bollywood movies starting with ‘a’ in the dataset.
select movie_name from movies where movie_name like 'a%';

#14. Retrieve the names of all the Bollywood movies having ‘a’ at second place of the name in the dataset.
select movie_name from movies where movie_name like '_a%';

#15. Retrieve the names of all the Bollywood movies having music of amit trivedi in the dataset.
select movie_name from movies where Music_Director='Amit Trivedi';

#16. Retrieve the names of all the comedy movies of Akshay Kumar in the dataset.
select movie_name from movies where Lead_Star='Akshay Kumar' AND Genre='comedy';

#17.Retrieve the names of movies and star name containing 'khan' in the dataset.
select movie_name,Lead_Star from movies where Lead_Star like '%Khan';

#18. Retrieve all the information of movies race and race2 in the dataset.
select * from movies where movie_name IN('Race','Race 2');

#19. Retrieve the names of all the thriller Bollywood movies in the dataset.
select movie_name from movies where Genre='Thriller';

#20.Retrieve the names and budget of all the Bollywood movies according to the highest budget to lowest budget in the dataset.
select movie_name,Budget from movies order by Budget desc;

#21.Retrieve the names and budget of top 5 Bollywood movies with highest budget in the dataset.
select movie_name,Budget from movies order by Budget desc limit 5;

#22.Retrieve the names of top 10 Bollywood movies with highest revenue generation in the dataset.
select movie_name,Revenue from movies order by Revenue desc limit 10;

#23.Retrieve the names of top 5 movies of salman khan in the dataset.
select movie_name,Revenue from movies where Lead_Star='Salman Khan' order by Revenue desc limit 5;

#24. Retrieve the names of top 5 floped movies in the dataset.
select movie_name As Flop_movies from movies where revenue<Budget order by(revenue-budget) desc limit 5;

#25.Retrieve the names of top 5 hit movies in the dataset.
select movie_name,Budget As Hit_movies from movies where Revenue>budget order by budget desc limit 5;


#26. Which is the second movie released on maximum screens.
select movie_name,Number_of_Screens from movies order by Number_of_Screens desc limit 1,1;

#27.Which is the 10th movies with highest budget.
select movie_name,Budget from movies order by budget desc limit 9,1;

#28. Which is the 2nd movie of Amitabh Bachchan with highest budget.
select movie_name,Lead_Star,Budget from movies where Lead_Star='Amitabh Bachchan' order by Budget desc limit 1,1;

#29. Which are the flopped movies of Akshay Kumar.
select movie_name,lead_star,(revenue-budget) as flop_movie from movies where (revenue - budget) < 0 and lead_star = 'Akshay Kumar';

#30. With which director Sharukh Khan have given the biggest hit movie .
select movie_name,lead_star,director,(revenue-budget) As profit from movies where (revenue-budget)>0 and lead_star='ShahRukh Khan' order by profit desc limit 1;